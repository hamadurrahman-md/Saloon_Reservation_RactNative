
Saloon Reservation App (React Native)

Features:
- Multi-saloon support
- Vibrant UI design
- Booking system with live availability
- Admin panel for saloon management

Setup Instructions:
1. Run npm install in user_app and admin_panel
2. Use Expo or React Native CLI to run user_app
3. Open admin_panel in browser using npm start

